
package sixth;


public class Sixth {

  
    public static void main(String[] args) {
        double d = 9.7;
        int a =(int) d ;
        System.out.println(a);
        System.out.println(d);
    }
    
}
