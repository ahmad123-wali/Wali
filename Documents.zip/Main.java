package pkg9;

public class Main {

    public static void main(String[] args) {
        int num1 = 1;
        int num2 = 2;
        boolean a = num1 > num2;
        System.out.println(a);
        boolean b = num1 <= num2;
        System.out.println(b);
        boolean c = num1 < num2;
        System.out.println(c);
        boolean d = num1 >= num2;
        System.out.println(d);
        boolean e = num1 == num2;
        System.out.println(e);
        boolean f = num1 != num2;
        System.out.println(f);

    }

}
